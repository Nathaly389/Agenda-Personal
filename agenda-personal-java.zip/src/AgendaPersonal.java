import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AgendaPersonal extends JFrame {
    private final JSpinner spinnerFecha;
    private final JSpinner spinnerHora;
    private final JTextArea txtDescripcion;
    private final DefaultTableModel tableModel;
    private final JTable table;

    public AgendaPersonal() {
        super("Agenda Personal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 450);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        // --- Entrada (panel superior) ---
        JPanel panelEntrada = new JPanel();
        panelEntrada.setBorder(BorderFactory.createTitledBorder("Nuevo evento"));
        panelEntrada.setLayout(new GridBagLayout());
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 6, 6, 6);
        c.fill = GridBagConstraints.HORIZONTAL;

        // Fecha
        c.gridx = 0; c.gridy = 0; c.weightx = 0;
        panelEntrada.add(new JLabel("Fecha (dd/MM/yyyy):"), c);
        spinnerFecha = new JSpinner(new SpinnerDateModel());
        spinnerFecha.setEditor(new JSpinner.DateEditor(spinnerFecha, "dd/MM/yyyy"));
        c.gridx = 1; c.gridy = 0; c.weightx = 1;
        panelEntrada.add(spinnerFecha, c);

        // Hora
        c.gridx = 0; c.gridy = 1; c.weightx = 0;
        panelEntrada.add(new JLabel("Hora (HH:mm):"), c);
        spinnerHora = new JSpinner(new SpinnerDateModel());
        spinnerHora.setEditor(new JSpinner.DateEditor(spinnerHora, "HH:mm"));
        c.gridx = 1; c.gridy = 1; c.weightx = 1;
        panelEntrada.add(spinnerHora, c);

        // Descripción
        c.gridx = 0; c.gridy = 2; c.weightx = 0; c.anchor = GridBagConstraints.NORTH;
        panelEntrada.add(new JLabel("Descripción:"), c);
        txtDescripcion = new JTextArea(3, 20);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane spDesc = new JScrollPane(txtDescripcion);
        c.gridx = 1; c.gridy = 2; c.weightx = 1; c.weighty = 1; c.fill = GridBagConstraints.BOTH;
        panelEntrada.add(spDesc, c);

        add(panelEntrada, BorderLayout.NORTH);

        // --- Tabla (panel central) ---
        String[] columnas = {"Fecha", "Hora", "Descripción"};
        tableModel = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // no editable desde la tabla
            }
        };
        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane spTabla = new JScrollPane(table);
        spTabla.setBorder(BorderFactory.createTitledBorder("Eventos"));
        add(spTabla, BorderLayout.CENTER);

        // --- Botones (panel sur) ---
        JPanel panelAcciones = new JPanel();
        panelAcciones.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.addActionListener(this::onAgregar);
        JButton btnEliminar = new JButton("Eliminar seleccionado");
        btnEliminar.addActionListener(this::onEliminar);
        JButton btnSalir = new JButton("Salir");
        btnSalir.addActionListener(e -> dispose());

        panelAcciones.add(btnAgregar);
        panelAcciones.add(btnEliminar);
        panelAcciones.add(btnSalir);

        add(panelAcciones, BorderLayout.SOUTH);
    }

    private void onAgregar(ActionEvent e) {
        String descripcion = txtDescripcion.getText();
        if (descripcion == null || descripcion.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "La descripción no puede estar vacía",
                    "Validación",
                    JOptionPane.WARNING_MESSAGE);
            txtDescripcion.requestFocusInWindow();
            return;
        }

        Date fechaVal = (Date) spinnerFecha.getValue();
        Date horaVal = (Date) spinnerHora.getValue();

        SimpleDateFormat sdfFecha = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfHora = new SimpleDateFormat("HH:mm");

        String fechaStr = sdfFecha.format(fechaVal);
        String horaStr = sdfHora.format(horaVal);

        // Insertar fila
        tableModel.addRow(new Object[]{fechaStr, horaStr, descripcion.trim()});

        // Limpiar descripción y devolver foco
        txtDescripcion.setText("");
        txtDescripcion.requestFocusInWindow();
    }

    private void onEliminar(ActionEvent e) {
        int fila = table.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this,
                    "Selecciona un evento primero",
                    "Atención",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        int opcion = JOptionPane.showConfirmDialog(this,
                "¿Eliminar el evento seleccionado?",
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION);

        if (opcion == JOptionPane.YES_OPTION) {
            tableModel.removeRow(fila);
        }
    }

    public static void main(String[] args) {
        // Ejecutar GUI en el hilo de despacho
        SwingUtilities.invokeLater(() -> {
            AgendaPersonal app = new AgendaPersonal();
            app.setVisible(true);
        });
    }
}